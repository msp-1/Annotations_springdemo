package com.exm;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Demo {
	private String id1;


	/*
	 * public Demo(String i) { id1 = i; System.out.println("1st const."); }
	 * 
	 * public Demo(int i,String j) { i=30; id1=j; System.out.println("2nd const.");
	 * }
	 */
	@Bean(name="b1")

	public String getId1() {
		
		System.out.println("In get method of Demo class");
		return "welcome";
	}

	public void setId1(String id1) {
		this.id1 = id1;
	}
	

}
