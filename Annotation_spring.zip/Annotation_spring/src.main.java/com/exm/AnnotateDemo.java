package com.exm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnotateDemo {
	public static void main(String[] args) {
	
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		Other object1=(Other) ac.getBean("obj");
		//object1.setD1("A");
		
		object1.disp();
		
	//System.out.println("Calling of method:"+object1.disp());

	}
	
		
	

	
	
}
