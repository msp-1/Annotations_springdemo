package com.exm;
//import java.beans.*;

public class Other {

	private int s11;
	private Demo d1;
	private Demo d2;
	public Demo getD1() {
		return d1;
	}
	
	
	public Other(Demo dd)
	{
		System.out.println("In construct");
	}
	public void setD1(Demo d1) {
		this.d1 = d1;
	}
	public Demo getD2() {
		return d2;
	}
	public void setD2(Demo d2) {
		this.d2 = d2;
	}
	
	public void disp()
	{
		System.out.println("In disp function1:"+getD1().getId1()+": Fun2:"+getD2().getId1());
		
	}
	


	public int getCheck() {
		return s11;
	}


	public void setCheck(int s11) {
		this.s11 = s11;
	}
	
}
