package com.exm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class WithAnnotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ac=new AnnotationConfigApplicationContext(Demo.class);
		Demo d=(Demo) ac.getBean("b1");
		//d.setId1("20");
		d.getId1();
		

	}

}
